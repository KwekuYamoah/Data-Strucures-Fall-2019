// BinarySearchTree class
//
// CONSTRUCTION: with no initializer
//
// ******************PUBLIC OPERATIONS*********************
// void insert( x )       --> Insert x
// void remove( x )       --> Remove x
// boolean contains( x )  --> Return true if x is present
// Comparable findMin( )  --> Return smallest item
// Comparable findMax( )  --> Return largest item
// boolean isEmpty( )     --> Return true if empty; else false
// void makeEmpty( )      --> Remove all items
// void printTree( )      --> Print tree in sorted order
// ******************ERRORS********************************
// Throws UnderflowException as appropriate

import java.util.Formatter;

/**
 * Implements an unbalanced binary search tree.
 * Note that all "matching" is based on the compareTo method.
 * @author Mark Allen Weiss
 * Modified by Ayorkor Korsah
 */
public class BinarySearchTree<T extends Comparable<? super T>>
{
  /** The tree root. */
  private BinaryNode<T> root;


  // Basic node stored in unbalanced binary search trees
  private static class BinaryNode<T>
  {
    T element;            // The data in the node
    BinaryNode<T> left;   // Left child
    BinaryNode<T> right;  // Right child

    // Constructors
    BinaryNode( T data )
    {
      this( data, null, null );
    }

    BinaryNode( T data, BinaryNode<T> lt, BinaryNode<T> rt )
    {
      element  = data;
      left     = lt;
      right    = rt;
    }
  }

  /**
   * Construct the tree.
   */
  public BinarySearchTree( )
  {
    root = null;
  }

  /**
   * Insert into the tree; duplicates are ignored.
   * This version of insert calls a private recursive method
   * @param x the item to insert.
   */
  public void insertV1(T x) {

    if (root == null)
      root =  new BinaryNode<T>(x);
    else
      insertV1(x, root); // call the private recursive method
  }

  /**
   * Private internal method to insert into a subtree rooted at a given node.
   * This method should not be called with a null value as the given node.
   * @param x the item to insert.
   * @param t the node that roots the subtree.
   * @return the new root of the subtree.
   */
  private void insertV1(T x, BinaryNode<T> subTreeRoot){
    int compareResult = x.compareTo(subTreeRoot.element);

    if (compareResult < 0){
      // insert in left subtree
      if (subTreeRoot.left == null)
        subTreeRoot.left = new BinaryNode<T>(x);
      else
        insertV1(x, subTreeRoot.left); // recursive call
    }
    else if (compareResult > 0){
      if (subTreeRoot.right == null)
        subTreeRoot.right = new BinaryNode<T>(x);
      else
        insertV1(x, subTreeRoot.right); // recursive call
    }

    // else compareResult == 0 i.e. they are equal
    // the item is already in the tree -- ignore.
  }

  /**
   * Insert into the tree; duplicates are ignored.
   * This version of insert also calls a private recursive method
   * The difference between this version and insertV1 is that the recursive
   * method used in this version is written in a slightly more elegant way
   * and returns the new subtree root to the caller
   * @param x the item to insert.
   */
  public void insert( T x )
  {
    root = insert( x, root );
  }

  /**
   * Private internal method to insert into a subtree rooted at a given node.
   * This method should not be called with a null value as the given node.
   * The difference between this version and insertV1 is that this version is
   * written in a slightly more elegant way and returns the new subtree root to the caller
   * @param x the item to insert.
   * @param t the node that roots the subtree.
   * @return the new root of the subtree.
   */
  private BinaryNode<T> insert( T x, BinaryNode<T> t )
  {
    if( t == null )
      return new BinaryNode<T>( x );

    int compareResult = x.compareTo( t.element );

    if( compareResult < 0 )
      t.left = insert( x, t.left );
    else if( compareResult > 0 )
      t.right = insert( x, t.right );

    return t;
  }

  /**
   * Insert into the tree; duplicates are ignored.
   * This version of insert is implemented iteratively rather than recursively
   * @param x the item to insert.
   */
  public void insertV2( T x)
  {
      BinaryNode<T> newNode = new BinaryNode<T>(x);
      BinaryNode<T> curNode = root;
      BinaryNode<T> parent = null;
      int compareResult = 0;

      // go down the tree, finding where to do the insertion.  At each step,
      // curNode refers to the current node, and parent to its parent.
      while (curNode != null) {
          parent = curNode;
          compareResult = x.compareTo(curNode.element);
          if (compareResult < 0)
              curNode = curNode.left;
          else if (compareResult > 0)
              curNode = curNode.right;
      }

      // insert the new node at the appropriate location
      if (parent == null)
          root = newNode; // parent will be null only if the root was null initially
      else if (compareResult < 0)
          parent.left = newNode;
      else if (compareResult > 0)
          parent.right = newNode;
  }

  /**
   * Find the smallest item in the tree.
   * @return smallest item or null if empty.
   */
  public T findMin( )
  {
    if( isEmpty( ) )
      throw new RuntimeException("Cannot find min element in an empty tree.");

    return findMin( root ).element;
  }

  /**
   * Internal method to find the smallest item in a subtree.
   * (Implemented recursively)
   * @param t the node that roots the subtree.
   * @return node containing the smallest item.
   */
  private BinaryNode<T> findMin( BinaryNode<T> t )
  {
    if( t == null )
      return null;

    else if( t.left == null )
      return t;

    else
      return findMin( t.left );
  }

  /**
   * Find the largest item in the tree.
   * @return the largest item of null if empty.
   */
  public T findMax( )
  {
    if( isEmpty( ) )
      throw new RuntimeException("Cannot find max element in an empty tree.");

    return findMax( root ).element;
  }

  /**
   * Internal method to find the largest item in a subtree.
   * (Implemented iteratively)
   * @param t the node that roots the subtree.
   * @return node containing the largest item.
   */
  private BinaryNode<T> findMax( BinaryNode<T> t )
  {
    // This method is implemented iteratively rather than
    // recursively, simply to show that it is possible to do so.
    if( t != null ) {
      while( t.right != null )
        t = t.right;
    }

    return t;
  }

  /**
   * Find an item in the tree.
   * @param x the item to search for.
   * @return true if not found.
   */
  public boolean contains( T x )
  {
    return contains( x, root );
  }

  /**
   * Internal method to find an item in a subtree.
   * @param x is item to search for.
   * @param t the node that roots the subtree.
   * @return node containing the matched item.
   */
  private boolean contains( T x, BinaryNode<T> t )
  {
    if( t == null )
      return false;

    int compareResult = x.compareTo( t.element );

    if( compareResult < 0 )
      return contains( x, t.left );

    else if( compareResult > 0 )
      return contains( x, t.right );

    else // compareResult == 0 i.e. they are equal
      return true;    // Match
  }

  /**
   * Make the tree logically empty.
   */
  public void makeEmpty( )
  {
    root = null;
  }

  /**
   * Test if the tree is logically empty.
   * @return true if empty, false otherwise.
   */
  public boolean isEmpty( )
  {
    return root == null;
  }

  /**
   * Print the tree contents in sorted order.
   * (I.e. it prints an in-order traversal of the tree)
   */
  public void printTree( )
  {
    if( isEmpty( ) )
      System.out.println( "Empty tree" );
    else {
      printTree( root );
      System.out.println();
    }
  }

  /**
     * Internal method to print a subtree in sorted order.
     * Note that this is an in-order traversal of the tree
     * @param t the node that roots the subtree.
     */
    private void printTree( BinaryNode<T> t )
    {
      if( t != null )
      {
        printTree( t.left );

        System.out.print( t.element + " " );

        printTree( t.right );
      }
    }

  /**
   * Remove from the tree. Nothing is done if x is not found.
   * @param x the item to remove.
   */
  public void remove( T x )
  {
    root = remove( x, root );
  }

  /**
   * Internal method to remove from a subtree.
   * @param x the item to remove.
   * @param t the node that roots the subtree.
   * @return the new root of the subtree.
   */
  private BinaryNode<T> remove( T x, BinaryNode<T> t )
  {
    if( t == null )
      return t;   // Item not found; do nothing

    int compareResult = x.compareTo( t.element );

    if( compareResult < 0 )
      t.left = remove( x, t.left );

    else if( compareResult > 0 )
      t.right = remove( x, t.right );

    else if( t.left != null && t.right != null ) // Two children
    {
      BinaryNode<T> nodeOnRightWithMinElt = findMin( t.right );
      t.element = nodeOnRightWithMinElt.element;
      t.right = remove( nodeOnRightWithMinElt.element, t.right );
    }

    else { // either one child or no children
      // replace t with its child, if any
      t = ( t.left != null ) ? t.left : t.right;

      /* Note that the code above is the same as the code below

       // one left child - replace t with its left child
       if (t.left != null)
          t = t.left;
       // one right child - replace t with its right child
       else
          t = t.right;
      */

    }

    return t;
  }


  /**
   * This method tries to draw a tree.  It's a little complicated because
   * to draw a tree, we need a level-order traversal of the tree.
   * That is, we move from a node to other nodes at the same level, rather
   * than moving to its children.  To facilitate that, we put nodes in a queue
   * as we encounter them.
   * Note that this is not a typical method you would find in a binary search tree class.
   * It is an interesting method though because it illustrates using one data
   * structure to implement an operation of another data structure.
   **/
  public void drawTree(){
    final int SMALLEST_SPACE = 2;
    int height = height(root);
    int maxNodes = (int) Math.pow(2, height+1)-1;
    int maxLeaves = maxNodes/2;
    int baseWidth = SMALLEST_SPACE*(maxLeaves);
    int center = baseWidth/2;
    Formatter formatter = new Formatter(System.out);

    // queue of nodes at the current level
    Queue<BinaryNode<T>> tempQ1 = new Queue<BinaryNode<T>>();
    tempQ1.enqueue(root);

    int lastSpace = (int) Math.pow(2, height+1);

    for (int i=0; i<=height; i++){
      int nodes = (int) Math.pow(2,i);
      int spaces =  (int) Math.pow(2, (height-i)) * SMALLEST_SPACE;
      int start = center - (nodes/2*spaces) + (i == 0 ? 0 : spaces/2);

      // queue of nodes at the next level
      Queue<BinaryNode<T>> tempQ2 = new Queue<BinaryNode<T>>();

      // type initial spacing
      for (int j=0;j<start; j++){
        System.out.print(" ");
      }

      int node = 0;
      while (!tempQ1.isEmpty()){
        BinaryNode<T> tempNode = tempQ1.dequeue();
        if (tempNode != null){
          // enqueue the children of the node
          tempQ2.enqueue(tempNode.left);
          tempQ2.enqueue(tempNode.right);
        } else {
          // enqueue null instead of children to make the spacing right
          tempQ2.enqueue(null);
          tempQ2.enqueue(null);
        }

        // display the value of the current node preceded by the correct number of spaces
        if (tempNode != null)
          formatter.format(("%"+(node==0 ? spaces-start : spaces) + "d"),tempNode.element);
        else
          formatter.format(("%"+ (node==0 ? spaces-start : spaces) + "s"),"");

        // put the correct number of spaces afterwards.
        for (int j=0; j<spaces; j++)
          System.out.print(" ");

        node++;
      }
      System.out.println();

      /* Attempt to print lines connecting the nodes.  Needs refinement.
      // type initial spacing
      for (int j=0;j<start; j++){
        System.out.print(" ");
      }
      for (int k=0; k<node; k++){
        for (int j=1; j<(k==0 ? spaces-start : spaces+1); j++)
          System.out.print("_");
        System.out.print("|");
        //formatter.format(("%"+ (k==0 ? spaces-start : spaces) + "s"),"|");
        // put the correct number of spaces afterwards.
        for (int j=0; j<spaces/2+1; j++)
          System.out.print("_");
      }
      System.out.println();
      */

      // the next level becomes the current level.
      tempQ1 = tempQ2;
    }
  }

  /**
   * Internal method to compute height of a subtree.
   * @param t the node that roots the subtree.
   */
  private int height( BinaryNode<T> t )
  {
    if( t == null )
      return -1;

    else
      return 1 + Math.max( height( t.left ), height( t.right ) );
  }
}
