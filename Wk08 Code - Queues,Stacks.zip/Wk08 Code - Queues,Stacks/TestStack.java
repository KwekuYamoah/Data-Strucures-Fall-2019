
public class TestStack {
 
  public static void main(String[] args) {
   
    String name1 = "Ama";
    String name2 = "Kofi";
    String name3 = "Bob";
   
    Stack<String> myStack = new Stack<String>();
    
    myStack.push(name1);
    myStack.push(name2);
    myStack.push(name3);
    
    String poppedItem;
    while (!myStack.isEmpty()){
      poppedItem = myStack.pop();
      
      System.out.println("Popped " + poppedItem);
    }
  }
}